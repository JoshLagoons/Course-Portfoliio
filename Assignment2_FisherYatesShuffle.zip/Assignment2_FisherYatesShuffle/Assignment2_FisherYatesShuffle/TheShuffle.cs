﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Assignment2_FisherYatesShuffle
{
   public static class TheShuffle
    {
        public static void Shuffle()
        {
            //Constructor
        }
        private static Random scrambledwords = new Random();
        //our variable in order to randomize stuff
        public static void MakeWordsShuffle(this object[] raspbaerry)
        {
            for(int icy = raspbaerry.Length-1; icy>0; icy--)
            {   //the integer icy is going one lower to the object that is greater than 0 making it the integer go down
                int cloudy = scrambledwords.Next(icy + 1);
                //the integer cloudy is equal to the next random word going up from the previous integer of icy
                Teleport(raspbaerry, icy, cloudy);
                //this is basically swapping but I see it as a teleport for them.
            }
            
        }
        public static void Teleport(object[] raspberry, int icy, int cloudy)
        {
            object gravel = raspberry[icy];
            raspberry[icy] = raspberry[cloudy];
            raspberry[cloudy] = gravel;
            //this is how the object gravel is equal to raspberry in icy 
            //but it goes in order that it goes to a loop around back to gravel again
        }
    }
}
