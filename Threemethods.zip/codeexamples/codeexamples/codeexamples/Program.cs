﻿using System;
using static System.Console;


namespace codeexamples
{
    class Program
    {
        static void Main(string[] args)
        {
            FirstPotatoBAKING();
            ProvideAllThePeanuts();
            ProvideMultipledPotatoes();
        }

        //quadratic n^2
        //Gives you the multiplier of the amount you asked
        //Having 5 it will give 25, asking for 25 will give 625.
        private static void ProvideMultipledPotatoes(int[] Potatoes)
        {
            var Softpotato;
            var Hardpotato;
            foreach (Softpotato in Potatoes)
            {
                foreach (Hardpotato in Potatoes)
                {
                    WriteLine($"{Softpotato}, {Hardpotato}");
                }
            }

        }

        //Linear n example
        //it gives the amount of peanuts that was ordered to
        //never receiving more or less but the exact amount
        private static void ProvideAllThePeanuts(int[] Peanuts)
        {
            foreach (var Peanut in Peanuts)
            {
                WriteLine(Peanuts);
            }

        }

        //O1 notation example
        // can give me 100 potatoes or less but it will be one 
        //single step to obtain the amount of potatoes
        private static void FirstPotatoBAKING(int[] Potato)
        {
            WriteLine(Potato[100]);

        }
    }
}
