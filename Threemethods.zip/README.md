# threemethods
this is the three notation example methods I present.
Still wrapping my brain around understanding the complexity of the notations and their purpose in coding. It is a lot to take in. 
Fascinated by how much it goes into the math of it and how the needed steps within the quadratic time and overall on calculating on space.
